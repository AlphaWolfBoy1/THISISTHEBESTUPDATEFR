-- special. dylanfreddys Shadow-Wolf Argentinean guy. learn more by telling me. discord: shadow1_wolf
-- argentina stuffs

--nodes

	--- Messi T Shirt
	--
	--  @chestplate argentina_stuffs:messi_t_shirt
	--  @img argentina_stuffs_inv_messi10.png
	--  @grp armor_torso 1
	--  @grp armor_heal 12
	--  @grp armor_use 100
	--  @grp armor_fire 1
	--  @armorgrp fleshy 20
	--  @damagegrp cracky 2
	--  @damagegrp snappy 1
	--  @damagegrp level 3
	armor:register_armor("argentina_stuffs:messi_t_shirt", {
		description = ("Messi T Shirt"),
		inventory_image = "argentina_stuffs_inv_messi10.png",
		groups = {armor_torso=1, armor_heal=12, armor_use=100, armor_fire=10},
		armor_groups = {fleshy=20},
		damage_groups = {cracky=2, snappy=1, level=3},
	})

minetest.register_node("argentina_stuffs:flag", {
	description = "Arg Flag",
  visual_scale = 2.0,
	tiles = {"argflag.png"},
    drawtype = "torchlike",
    sunlight_propagates = true,
    paramtype = "light",
    groups = {plastic = 5, dig_immediate = 3},
})


minetest.register_craftitem("argentina_stuffs:raw_milanesa", {
	description = ("Milanesa Argentina Cruda"),
	inventory_image = "raw_milanesa.png",
	on_use = minetest.item_eat(1),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:milanesa", {
	description = ("Milanesa Argentina"),
	inventory_image = "milanesa.png",
	on_use = minetest.item_eat(18),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:raw_empanada", {
	description = ("Empanada Argentina Cruda"),
	inventory_image = "raw_empanada.png",
	on_use = minetest.item_eat(1),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:empanada", {
	description = ("Empanada Argentina"),
	inventory_image = "empanada.png",
	on_use = minetest.item_eat(15),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:mate", {
	description = ("Mate Argentino"),
	inventory_image = "mate.png",
	on_use = minetest.item_eat(4),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:torta_frita", {
	description = ("Argentine Fried Cake"),
	inventory_image = "tortaf.png",
	on_use = minetest.item_eat(7),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:torta_frita_masa", {
	description = ("Fried Cake Dough"),
	inventory_image = "doughf.png",
	on_use = minetest.item_eat(1),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:asado_crudo", {
	description = ("Raw Asado"),
	inventory_image = "raw_asado.png",
	on_use = minetest.item_eat(1),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:asado", {
	description = ("Asado Argentino"),
	inventory_image = "asado.png",
	on_use = minetest.item_eat(16),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:asado_picante", {
	description = ("Asado & chimichurri"),
	inventory_image = "asadoychimi.png",
	on_use = minetest.item_eat(20),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:chimichurri", {
	description = ("chimichurri"),
	inventory_image = "chimichurri.png",
	on_use = minetest.item_eat(2),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:raw_chorizo", {
	description = ("Chorizo Argentino Crudo"),
	inventory_image = "raw_sausagearg.png",
	on_use = minetest.item_eat(1),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:chorizo", {
	description = ("Chorizo Argentino"),
	inventory_image = "sausagearg_cooked.png",
	on_use = minetest.item_eat(10),
	groups = {compostability = 1}
})


minetest.register_craftitem("argentina_stuffs:choripan", {
	description = ("Choripan Argentino"),
	inventory_image = "choripan.png",
	on_use = minetest.item_eat(15),
	groups = {compostability = 1}
})

minetest.register_craftitem("argentina_stuffs:bucket_with_sweetmilk", {
	description = ("Milk With Sugar"),
	inventory_image = "sweetmilk.png",
	on_use = minetest.item_eat(5),
	groups = {compostability = 0}
})


minetest.register_craftitem("argentina_stuffs:bucket_with_dulcedeleche", {
	description = ("Dulce De Leche Argentino"),
	inventory_image = "dulcedeleche.png",
	on_use = minetest.item_eat(8),
	groups = {compostability = 0}
})

-- crafts

minetest.register_craft({
	type = "cooking",
	cooktime = 20,
	output = "argentina_stuffs:milanesa",
	recipe = "argentina_stuffs:raw_milanesa"
})

minetest.register_craft({
	output = 'argentina_stuffs:raw_milanesa',
	recipe = {
		{'', 'farming:bread_slice', ''},
		{'', 'group:food_meat', ''},
		{'', 'farming:bread_slice', ''},
	}
})

minetest.register_craft({
	type = "cooking",
	cooktime = 10,
	output = "argentina_stuffs:empanada",
	recipe = "argentina_stuffs:raw_empanada"
})

minetest.register_craft({
	output = 'argentina_stuffs:raw_empanada',
	recipe = {
		{'group:food_wheat', 'group:food_wheat', 'group:food_wheat'},
		{'', 'group:food_meat', ''},
		{'', 'farming:bread_slice', ''},
	}
})


minetest.register_craft({
	output = 'argentina_stuffs:mate',
	recipe = {
		{'default:steel_ingot', 'bucket:bucket_water', 'default:steel_ingot'},
		{'default:steel_ingot', 'default:grass_1', 'default:steel_ingot'},
		{'', 'default:steel_ingot', 'farming:sugar'},
	}
})


minetest.register_craft({
	output = 'argentina_stuffs:torta_frita_masa',
	recipe = {
		{'farming:sugar', 'bucket:bucket_water', ''},
		{'group:food_wheat', 'farming:bread_slice', ''},
		{'farming:sugar', 'farming:sugar', 'farming:sugar'},
	}
})


minetest.register_craft({
	type = "cooking",
	cooktime = 10,
	output = "argentina_stuffs:torta_frita",
	recipe = "argentina_stuffs:torta_frita_masa"
})


minetest.register_craft({
	output = 'argentina_stuffs:asado_crudo',
	recipe = {
		{'', 'group:food_meat', ''},
		{'group:food_meat', 'group:food_meat', 'group:food_meat'},
		{'', 'group:food_meat', ''},
	}
})


minetest.register_craft({
	type = "cooking",
	cooktime = 8,
	output = "argentina_stuffs:asado",
	recipe = "argentina_stuffs:asado_crudo"
})


minetest.register_craft({
	output = 'argentina_stuffs:asado_picante',
	recipe = {
		{'', 'argentina_stuffs:chimichurri', ''},
		{'', 'argentina_stuffs:asado', ''},
		{'', 'default:steel_ingot', ''},
	}
})


minetest.register_craft({
	output = 'argentina_stuffs:chimichurri',
	recipe = {
		{'', 'farming:chili_pepper', ''},
		{'farming:pepper_yellow', 'farming:peppercorn', 'farming:pepper_yellow'},
		{'default:steel_ingot', 'farming:pepper', 'default:steel_ingot'},
	}
})


minetest.register_craft({
	output = 'argentina_stuffs:raw_chorizo',
	recipe = {
		{'', 'group:food_meat', ''},
		{'farming:chili_pepper', 'group:food_meat', 'group:food_meat'},
		{'', 'group:food_meat', ''},
	}
})


minetest.register_craft({
	type = "cooking",
	cooktime = 7,
	output = "argentina_stuffs:chorizo",
	recipe = "argentina_stuffs:raw_chorizo"
})


minetest.register_craft({
	output = 'argentina_stuffs:choripan',
	recipe = {
		{'', 'argentina_stuffs:chimichurri', ''},
		{'', 'argentina_stuffs:chorizo', ''},
		{'farming:bread_slice', 'farming:bread_slice', 'farming:bread_slice'},
	}
})


minetest.register_craft({
	output = 'argentina_stuffs:bucket_with_sweetmilk',
	recipe = {
		{'', 'farming:sugar', ''},
		{'', 'farming:sugar', ''},
		{'', 'mobs:bucket_milk', ''},
	}
})


minetest.register_craft({
	type = "cooking",
	cooktime = 9,
	output = "argentina_stuffs:bucket_with_dulcedeleche",
	recipe = "argentina_stuffs:bucket_with_sweetmilk"
})


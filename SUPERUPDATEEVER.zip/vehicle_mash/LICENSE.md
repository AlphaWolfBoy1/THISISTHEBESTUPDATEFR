# Credit where credit is due

Copyright (C) 2015-2016 blert2112 and contributors\
Copyright (C) 2019-2022 Panquesito7 (halfpacho@gmail.com) and contributors

- Black, Blue, Brown, Cyan, Dark Green, Dark Grey, Green, Grey, Magenta, Orange, Pink, Red, Violet, White, Yellow, Hot Rod, Nyan Ride, Oerkki Bliss, and Road Master from: "Car" by Esteban
  - <https://forum.minetest.net/viewtopic.php?f=13&t=7407>
  - License:
    - No info given in that mod but I am going to assume the credit for the original model goes to:
    - Melcor and his CAR01 model (MELKAR)
    - <https://forum.minetest.net/viewtopic.php?f=9&t=6512>
    - License: [CC BY-NC-SA 3.0](https://creativecommons.org/licenses/by-nc-sa/3.0/)

- MeseCars from: "Mesecars" by paramat
  - <https://forum.minetest.net/viewtopic.php?f=11&t=7967>
  - Licenses: Code WTFPL, textures CC BY-SA

- Boats from "Boats" by PilzAdam
- <https://github.com/PilzAdam/boats>
  - textures: Zeg9
  - model: thetoon and Zeg9, modified by PavelS(SokolovPavel)
  - License: [WTFPL](http://www.wtfpl.net/)

- Hovercraft from "Hovercraft" by Stuart Jones
- <https://github.com/stujones11/hovercraft>
  - Licenses:
    - textures: CC-BY-SA
    - sounds: freesound.org
      - Rocket Boost Engine Loop by qubodup - CC0
      - CARTOON-BING-LOW by kantouth - CC-BY-3.0
      - All other sounds: Copyright Stuart Jones - CC-BY-SA

I am sure many others deserve mention.\
If you feel left out let me know and I will add you in.


------------------ Basic Join/left message ------------------

-- Message when the player joins the server

join_prefix_msg = "[DCWS] -> The Player "
join_color_msg = "#99fc60"
join_message = " joined Dark Caves WildSurvival."

join_color_player_name = "#6d6d6d"

-- Message when the player leaves the server

left_prefix_msg = "[DCWS] -> The Player "
left_color_msg = "#ff4f19"
left_message = " left Dark Caves WildSurvival."

left_color_player_name = "#6d6d6d"


------------------ Staff Join/left message ------------------

---- Optional configuration, only with staffranks mod

ranks_staff = {"admin", "modo", "guardian", "dev", "build", "helper", "youtuber", "miner", "reporter", "pro-pvp", "retired", "rebel", "guide", "pro", "hero", "spanish", "cop", "fly", "super"}

-- Message when the player joins the server

st_join_prefix_msg = "[Ranked Player] The player "
st_join_color_msg = "#99fc60"
st_join_msg = " joined Dark Caves WildSurvival."

st_join_color_player_name = "#005eef"

-- Message when the player leaves the server

st_left_prefix_msg = "[Ranked Player] The player "
st_left_color_msg = "#ef1600"
st_left_message = " left Dark Caves WildSurvival."

st_left_color_player_name = "#005eef"

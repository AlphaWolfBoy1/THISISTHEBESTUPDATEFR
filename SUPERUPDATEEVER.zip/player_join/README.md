#Player_Join

To change colors and messages go to config.lua.
In config.lua:

join_prefix_msg = The message sent before the nickname, when a player joins the server. (Default: [Server] -> )
join_color_msg = The color of the message when the player joins the server, outside the player’s name. (Default: "#00d11d")
join_message = Message to say the player has joined the server. (Default: " joined the game.")
join_color_player_name = Color of the player when he joins the server. (Default: "#00d8ea")

left_prefix_msg = The message sent before the nickname, when a player leaves the server. (Default: [Server] -> )
left_color_msg = The color of the message when the player leaves the server, outside the player’s name. (Default: "#00d11d")
left_message = Message to say the player has to leave the server. (Default: " left the game.")
left_color_player_name = Color of the player when he leaves the server. (Default: "#00d8ea")

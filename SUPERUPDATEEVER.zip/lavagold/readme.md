# lavagold

add lavagold
textures attribution

Cisoun's texture pack (CC BY-SA 3.0):
  default_lava.png

BlockMen (CC BY-SA 3.0):
  default_lava_source_animated.png
  default_lava_flowing_animated.png